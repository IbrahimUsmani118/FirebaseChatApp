//
//  Constants.swift
//  FirebaseLogin
//
//  Created by Ibrahim Usmani
//

import Foundation


struct Constants {
    
    static let loginSegue = "LoginToChat"
    static let registerSegue = "RegisterToChat"
    
}
