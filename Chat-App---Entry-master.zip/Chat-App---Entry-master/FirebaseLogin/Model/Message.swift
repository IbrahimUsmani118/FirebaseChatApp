//
//  Message.swift
//  FirebaseLogin
//
//  Created by Ibrahim Usmani
//

import Foundation

struct Message {
  
    let sender : String
    
    let body : String
    
}
